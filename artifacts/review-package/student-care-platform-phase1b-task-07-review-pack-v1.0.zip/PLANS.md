# Phase 1A 批次B执行计划（历史冻结）

## 权威与状态

- 当前阶段：`PHASE_1A_BATCH_B`（历史计划）
- 执行合同：`PHASE_1A_BATCH_B_CODEX_EXECUTION.md`
- 合同 SHA-256：`8DE2E96EB129E05950F8BC3832C5CEB842A1565BC5512E201F7EB233AC6DE04E`
- 源分支/源 HEAD：`planning/phase-1a-batch-a` / `f698f87150dce3376fb96d1bbb330d28d0d73b81`
- 目标分支：`planning/phase-1a-batch-b`
- 历史停止字段：`PHASE_1B_STARTED=NO`、`PROJECT_OWNER_ACCEPTANCE=PENDING`（`HISTORICAL/FROZEN`）
- 当前 Phase 1B 活动治理：`docs/project/PHASE_1B_GOVERNANCE_AND_API_FRAMEWORK_AUTHORITY_V10.md`（SHA-256：`161A8C57154A63ADFE8A6AE94FAC29A76EC50EFA0A6BD2719F172C1553CA5538`）
- 当前状态：`PHASE_1B_STARTED=YES_FOR_TASK_01_TO_TASK_07_STAGE_C1_ONLY`；Task 01—06 已由负责人验收并冻结，Task 07 Stage A 已通过负责人审阅，Task 07 Stage B 已通过并冻结，Task 07 Stage C1 已形成最终证据并等待负责人审阅，Task 07 C2 及 Task 08+ 未启动且未授权
- `TASK_04_STARTED=YES`
- `TASK_04_IMPLEMENTATION_AUTHORIZATION=GRANTED`
- `TASK_05_STARTED=YES`
- `TASK_05_IMPLEMENTATION_AUTHORIZATION=GRANTED`
- `TASK_05_STAGE_C1_STATUS=FINAL_EVIDENCE_READY`
- `TASK_05_STAGE_C2_STATUS=ACCEPTED`
- `TASK_05_OWNER_REVIEW=ACCEPTED_AND_FROZEN`
- `TASK_06_STARTED=YES_STAGE_B_IMPLEMENTATION`
- `TASK_06_IMPLEMENTATION_AUTHORIZATION=GRANTED`
- `TASK_06_STAGE_B_STATUS=IMPLEMENTED_AND_VERIFIED`
- `TASK_06_STAGE_C1_STATUS=FINAL_EVIDENCE_READY_AND_OWNER_REVIEW_PASSED`
- `TASK_06_OWNER_REVIEW=ACCEPTED`
- `TASK_06_STAGE_C2_STATUS=ACCEPTED`
- `TASK_06_STAGE_C2_AUTHORIZATION=GRANTED`
- `TASK_07_STARTED=YES_STAGE_C1_EVIDENCE`
- `TASK_07_STAGE_A_AUTHORIZATION=GRANTED`
- `TASK_07_STAGE_A_STATUS=OWNER_REVIEW_PASSED`
- `TASK_07_STAGE_B_STATUS=IMPLEMENTED_AND_VERIFIED`
- `TASK_07_STAGE_B_IMPLEMENTATION_AUTHORIZATION=GRANTED`
- `TASK_07_STAGE_C1_STATUS=FINAL_EVIDENCE_READY`
- `TASK_07_STAGE_C1_AUTHORIZATION=GRANTED`
- `TASK_07_STAGE_C2_STATUS=NOT_STARTED`
- `TASK_07_STAGE_C2_AUTHORIZATION=NOT_GRANTED`
- `TASK_07_PLUS_STARTED=NO`
- `TASK_07_PLUS_AUTHORIZATION=NOT_GRANTED`
- 当前 API/runtime：Fastify 5.12.1；Node 24.14.0；pnpm 11.22.0
- 当前依赖裁决：T12=`T02 -> T03 -> T05`；T10=`T05 -> T08 -> T12`

Batch A 已由项目负责人验收为 `PASS`，其 ZIP、根清单、报告、文件清单、验证器、低保真原型、截图和既有产品/架构/AI文档均为冻结输入。Batch B 只增加合同白名单内的治理、设计、原型、基线、验证和证据文件。

## 执行顺序

| 阶段 | 任务合同              | 主要产物                                           | 固定提交                                                   |
| ---- | --------------------- | -------------------------------------------------- | ---------------------------------------------------------- |
| B0   | `PHASE_1A_BATCH_B_B0` | 只读门禁回执                                       | 无                                                         |
| B1   | `PHASE_1A_BATCH_B_B1` | 验收记录、决策基线、范围、执行计划、根治理更新     | `chore: activate phase 1a batch b design baseline`         |
| B2   | `PHASE_1A_BATCH_B_B2` | 视觉分析、品牌 UI 规范、组件和响应式规则           | `docs: define tongxin cross-end design system`             |
| B3   | `PHASE_1A_BATCH_B_B3` | 59 路由高保真原型、原创 SVG、模拟数据              | `feat: add phase 1a high fidelity prototypes`              |
| B4   | `PHASE_1A_BATCH_B_B4` | V0.1 技术基线、契约、追踪矩阵、Phase 1B 计划       | `docs: finalize v0.1 technical baseline and phase 1b plan` |
| B5   | `PHASE_1A_BATCH_B_B5` | 标准库验证器、浏览器验证和响应式/负测证据          | 无                                                         |
| B6   | `PHASE_1A_BATCH_B_B6` | 15 张截图、评审报告、清单、独立 manifest、审查 ZIP | 无                                                         |
| B7   | `PHASE_1A_BATCH_B_B7` | 最终门禁与回执                                     | `test: add phase 1a batch b review evidence`               |

每个任务都必须先完成合同实例中的目标、白名单、验收点、命令和停止条件，再实施、验证、显式暂存和提交。禁止 `git add .`、`git add -A`、amend、rebase、reset、remote、push 和部署。

## B0 硬门禁

只读核验项目根、合同 SHA、源分支、源 HEAD、目标分支 provenance、工作区和 index、忽略路径、Git remote、Batch A 冻结证据、Batch A ZIP 三项指标、四个视觉输入、根目录额外 ZIP、Batch B 固定 ZIP和精确未跟踪输入集。旧 Batch A 阶段敏感验证器不得在 Commit 4 上运行；冻结报告的历史 `PENDING` 字段不得回写。任何合同、哈希、归属、权限或文件边界异常立即停止。

## B1 治理基线

允许文件：

- `.gitignore`
- `AGENTS.md`
- `README.md`
- `PLANS.md`
- `docs/project/PHASE_1A_BATCH_A_ACCEPTANCE.md`
- `docs/project/PHASE_1A_BATCH_B_DECISION_BASELINE.md`
- `docs/project/PHASE_1A_BATCH_B_SCOPE_AND_NON_SCOPE.md`
- `docs/plans/PHASE_1A_BATCH_B_EXEC_PLAN.md`

`phase-inputs/phase1a-batch-b/` 只读、忽略、未跟踪，不进入提交。Batch A 冻结路径不在 B1 白名单中。

## B2 设计系统

读取四个批准视觉输入，仅提取布局、卡片、留白、信息层级和跨端结构；不得复制原配色、人物、机器人、图标、水印、文案或完整页面。输出设计文档、组件清单、可访问性、响应式和原创插画规则。所有新插画和图标必须为本地原创 SVG；批准的机构 Logo 是唯一可直接使用的输入图像。

## B3 高保真原型

创建 `prototypes/high-fidelity/`，只使用原生 HTML、CSS Custom Properties、原生 JavaScript、本地 PNG/SVG、hash 路由和内存模拟数据。不得创建 `package.json`、应用脚手架、网络请求、外部字体、持久化存储或正式服务。

路由集合必须与 Batch A `PAGE_INVENTORY.md` 保持一致：A 级 47 个（小程序 20、用户网页 13、管理网页 14），B 级流程 12 个，C 级 10 个只作未来预留，不进入可执行原型。三条闭环必须可点击完成：家长绑定、教师任务至工作日报、监督式 AI 学习至教师摘要。AI 必须按“先尝试、第 0/1/2/3 层、1—3 道巩固题、转教师或关闭”推进。

## B4 基线与 Phase 1B 计划

创建合同白名单中的 `*_BASELINE.md`、V0.1 JSON/Markdown 契约、追踪矩阵和包含 18 个独立 TDD 任务的 `PHASE_1B_V0_1_IMPLEMENTATION_PLAN.md`。明确技术栈、未来 monorepo 结构、多租户、Membership、对象级权限、数据模型、API 错误、文件/COS 边界、环境、测试、日志审计、迁移回滚、隐私和 AI 网关。只写计划，不创建 `apps/`、`packages/`、数据库迁移或正式代码。

## B5 验证

验证器只能使用 Python 标准库和现有运行时。验证页面集合、59 路由、12 流程状态守卫、三条闭环、AI 层级、原创 SVG、禁止外部请求/持久化、模拟数据、可访问性静态约束和合同白名单。浏览器验证优先使用当前已有 Chrome/Playwright；不得安装依赖。记录浏览器版本、Playwright 版本、页面错误、严重控制台错误、外部请求和失败请求。

## B6 证据包

固定生成 15 张真实浏览器截图。固定 ZIP：`artifacts/review-package/student-care-platform-phase1a-batch-b-review-pack-v1.0.zip`。独立根清单：`SHA256SUMS_PHASE_1A_BATCH_B.txt`，不得覆盖 Batch A 的 `SHA256SUMS.txt`。ZIP 成员必须精确为合同列出的 86 项，路径按 POSIX Unicode 升序、UTF-8 无 BOM、LF 和单一末尾 LF 计算名单 SHA：`B6ED195F1F41AB731F53AFA65071037BE23A56F3547B543160A41F0CE6A33C30`。运行时集合不匹配时不得生成或覆盖 ZIP。

## HISTORICAL/FROZEN：B7 最终门禁与停止

以下内容是 Batch B 当时的历史停止回执，不是当前 Phase 1B 活动治理。历史上最终验证五个提交顺序、冻结证据无漂移、合同 SHA、工作区/index/remote、59/59 路由、15 张截图、86 成员和两份清单，并要求最终回执保留：

```text
PHASE_1A_BATCH_B_STATUS=PASS|BLOCKED
PHASE_1B_STARTED=NO
PRODUCTION_DEPLOYMENT_EXECUTED=NO
GIT_PUSH_EXECUTED=NO
REAL_PERSONAL_DATA_USED=NO
LIVE_AI_MODEL_USED=NO
PROJECT_OWNER_ACCEPTANCE=PENDING
```

在该 `HISTORICAL/FROZEN` Batch B 语境中，`PASS` 只表示内部证据门禁通过；当时要求输出最终回执后立即停止，等待项目负责人验收，不进入 Phase 1B。上述 `PHASE_1B_STARTED=NO`、`PROJECT_OWNER_ACCEPTANCE=PENDING` 和“不进入 Phase 1B”均是负责人验收前的历史快照，不覆盖本文件顶部引用的当前 authority。
