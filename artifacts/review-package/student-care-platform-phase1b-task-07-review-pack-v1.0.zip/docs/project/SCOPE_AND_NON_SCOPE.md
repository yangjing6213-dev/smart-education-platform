# 当前 Phase 1B 活动治理与范围

当前 Phase 1B 追认 Task 01—06 已完成并冻结；Task 06 C2 acceptance 仅记录验收；Task 07 Stage A 已通过负责人审阅，Stage B 已通过并冻结，Stage C1 已获独立负责人授权并正在形成最终证据，C2 与 Task 08+ 不开启。
活动治理以
`docs/project/PHASE_1B_GOVERNANCE_AND_API_FRAMEWORK_AUTHORITY_V10.md`
为准（SHA-256：`161A8C57154A63ADFE8A6AE94FAC29A76EC50EFA0A6BD2719F172C1553CA5538`）。

```text
PHASE_1B_STARTED=YES_FOR_TASK_01_TO_TASK_07_STAGE_C1_ONLY
PHASE_1B_COMPLETED_TASKS=TASK_01|TASK_02|TASK_03|TASK_04|TASK_05|TASK_06
TASK_04_STARTED=YES
TASK_04_IMPLEMENTATION_AUTHORIZATION=GRANTED
TASK_05_STARTED=YES
TASK_05_IMPLEMENTATION_AUTHORIZATION=GRANTED
TASK_05_STAGE_C1_STATUS=FINAL_EVIDENCE_READY
TASK_05_STAGE_C2_STATUS=ACCEPTED
TASK_05_OWNER_REVIEW=ACCEPTED_AND_FROZEN
TASK_06_STARTED=YES_STAGE_B_IMPLEMENTATION
TASK_06_IMPLEMENTATION_AUTHORIZATION=GRANTED
TASK_06_STAGE_B_STATUS=IMPLEMENTED_AND_VERIFIED
TASK_06_STAGE_C1_STATUS=FINAL_EVIDENCE_READY_AND_OWNER_REVIEW_PASSED
TASK_06_OWNER_REVIEW=ACCEPTED
TASK_06_STAGE_C2_STATUS=ACCEPTED
TASK_06_STAGE_C2_AUTHORIZATION=GRANTED
TASK_06_ACCEPTANCE_PATH=docs/project/PHASE_1B_TASK_06_ACCEPTANCE.md
TASK_06_ACCEPTANCE_SHA256=0B690B77CF4C08653FAE3495ABB9B218C640E8C4F02121CC14DEE0557850F68C
TASK_07_STARTED=YES_STAGE_C1_EVIDENCE
TASK_07_STAGE_A_AUTHORIZATION=GRANTED
TASK_07_STAGE_A_STATUS=OWNER_REVIEW_PASSED
TASK_07_STAGE_B_STATUS=IMPLEMENTED_AND_VERIFIED
TASK_07_STAGE_B_IMPLEMENTATION_AUTHORIZATION=GRANTED
TASK_07_STAGE_C1_STATUS=FINAL_EVIDENCE_READY
TASK_07_STAGE_C1_AUTHORIZATION=GRANTED
TASK_07_STAGE_C2_STATUS=NOT_STARTED
TASK_07_STAGE_C2_AUTHORIZATION=NOT_GRANTED
TASK_07_PLUS_STARTED=NO
TASK_07_PLUS_AUTHORIZATION=NOT_GRANTED
PHASE_1B_API_FRAMEWORK=FASTIFY_5.12.1
NESTJS_REFERENCE_POLICY=HISTORICAL_DRAFT_ONLY
PHASE_1B_NODE_VERSION=24.14.0
PHASE_1B_PNPM_VERSION=11.22.0
T12_DEPENDENCIES=T02 -> T03 -> T05
T10_DEPENDENCIES=T05 -> T08 -> T12
```

本文件下方原有 Phase 1A 范围记录及旧状态整体为 `HISTORICAL/FROZEN`，不与上述当前活动范围竞争，也不因当前 authority 回写。Batch B 冻结记录中的 `PROJECT_OWNER_ACCEPTANCE=PENDING` 是负责人验收前的历史快照；当前 authority 记录后续 `BATCH_B_PROJECT_OWNER_ACCEPTANCE=PASS` 裁决。

本次按 `CHANGE_CONTROL.md` §5 采用 `HISTORICAL_FREEZE_PLUS_ACTIVE_REFERENCE_CLOSURE`，活动原子范围精确为 V9 authority、全部活动治理引用文件和 Task 07 Stage B repair/implementation 合同与验证边界。V8及更早 authority、Task 01—06 合同、验收、C1证据和 Batch A/Batch B 固定证据仍为冻结引用，不在当前改写范围内。

# HISTORICAL/FROZEN：Phase 1A 范围与非范围

## 1. 当前范围边界

唯一范围是 Phase 1A 批次A。交付以文档、低保真原型、验证脚本和审查证据为限；当前 A1 只建立治理基线，不提前创建 A2—A7 的正式产物。

## 2. 合同12项交付

| 序号 | 合同交付                             | 对应阶段 | 验收证据                                 |
| ---: | ------------------------------------ | -------- | ---------------------------------------- |
|    1 | 项目治理与仓库基线                   | A0—A1    | 根治理文件、项目治理文件、模板、Commit 1 |
|    2 | 产品总PRD和V0.1专项PRD               | A2       | 两份PRD及范围覆盖检查                    |
|    3 | 用户角色与三端功能矩阵               | A2       | 角色矩阵、端侧矩阵                       |
|    4 | 完整页面清单                         | A2       | A/B/C级页面、字段和验收点                |
|    5 | 核心用户流程                         | A2、A4   | 八条流程文档与三条可点击闭环             |
|    6 | 内容字段和状态定义                   | A2       | 内容模式与状态模型                       |
|    7 | 低保真可点击跨端原型                 | A4       | 三端入口、A级导航、B级状态转换           |
|    8 | 多租户、统一账号、权限和数据模型草案 | A3       | 架构草案与隔离检查                       |
|    9 | API边界、文件、环境和部署草案        | A3       | API、文件、环境与部署文档；不实际部署    |
|   10 | 同芯AI学习助手产品与安全草案         | A3—A4    | 产品、安全、流程、评测草案与五层原型     |
|   11 | 验收标准和验证脚本                   | A2、A5   | 验收标准、脚本、命令结果                 |
|   12 | Phase 1A批次A审查包                  | A6—A7    | 评审、清单、校验和、ZIP、最终回执        |

任何交付都必须同时满足术语、三端、多租户、未成年人、模拟数据、AI边界和证据规则。

依赖不是本批次的隐含手段。A0—A7 一律不安装依赖，浏览器能力不可用或失败时仅做静态链接与内容检查。未来如确需最小验证依赖，必须由项目负责人在新任务合同中批准包名、版本、必要性、影响和回退，并先形成新版权威执行合同、新 SHA、原子更新全部引用且重新批准；当前合同不允许例外。

## 3. 明确非范围

- 正式微信小程序、Next.js 用户端、机构管理后台、NestJS API 或其他业务应用；
- 正式数据库迁移、生产数据模型落库、Redis/COS/微信/伙伴云实际集成；
- 真实登录、短信、微信授权、微信支付、收费、结算或支付测试；
- 正式 AI 模型、模型供应商调用、RAG 实现、真实评测或真实学生 AI 会话；
- 真实学生、家长、教师、工作人员数据及任何可识别未成年人内容；
- 生产密钥、真实令牌、证书、账号或服务器访问；
- 腾讯云上传、测试部署、生产部署、域名、备案或监控；
- Git 远程配置、推送、PR、公开发布；
- A0—A7 的任何依赖安装、正式框架脚手架和批次A之外的代码；
- Phase 1A 批次B、Phase 1B 及之后材料。

## 4. A0—A7 固定顺序

```text
A0 执行前硬门禁
→ A1 Git与项目治理基线
→ A2 产品规格基线
→ A3 架构、数据、权限与AI安全草案
→ A4 三端低保真可点击原型
→ A5 自动验证与原型验证
→ A6 审查证据与压缩包
→ A7 Commit 4、最终门禁与停止
```

每项均需单独任务合同和退出证据。上一步内部通过不自动授权下一步。

## 5. 四提交边界

| 提交     | 覆盖阶段 | 固定消息                                           |
| -------- | -------- | -------------------------------------------------- |
| Commit 1 | A1       | `chore: establish phase 1a project governance`     |
| Commit 2 | A2       | `docs: define phase 1a batch a product baseline`   |
| Commit 3 | A3       | `docs: draft platform architecture and ai safety`  |
| Commit 4 | A4—A7    | `feat: add phase 1a low fidelity review prototype` |

评审报告记录 Commit 1—3，并说明 Commit 4 固化报告自身；Commit 4 最终哈希只写入提交后的终端回执。

## 6. 阻塞与强制停止

出现以下任一情况必须停止：

1. 合同缺失或 SHA 不等于冻结值；
2. 发现无关文件、未授权修改、额外提交或远程配置；
3. 合同、裁决和已批准文档存在无法判定的实质冲突；
4. 需要真实数据、生产密钥、正式模型、支付、外部 API、安装依赖、推送或部署才能继续；
5. 跨租户隔离、未成年人保护或 AI 安全边界无法满足；
6. 验证失败且不能在当前任务合同白名单内安全修复；
7. 任务要求进入批次B、Phase 1B 或正式开发；
8. 证据不足却要求声明完成或 `PASS`。

停止时保留已验证成果，记录事实、影响、最小解除条件和所需批准。禁止伪造证据、扩大范围或猜测修复。
